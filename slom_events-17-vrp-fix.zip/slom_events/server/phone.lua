local vRP = E.vrp
local openRoot, openEvent
local resource = GetCurrentResourceName()
local handingOff = {}
local function escape(value)
    return tostring(value or ''):gsub('&','&amp;'):gsub('<','&lt;'):gsub('>','&gt;'):gsub('"','&quot;'):gsub("'",'&#39;')
end

local function permitted(player,id,admin)
    return Config.Phone.Enabled and E.uid(player) == id and
        ((admin and Config.Phone.AdminEnabled and E.has(id,'OpenAdmin'))
        or (not admin and Config.Phone.PlayerEnabled))
end

local function menuFor(player,id,admin,key,title,back,build)
    if not id or not permitted(player,id,admin) then return end
    if not E.ready then E.notify(player,L.offline,'error') return end
    vRP.buildMenu({key,{player=player},function(menu)
        if not E.ready or not permitted(player,id,admin) then return end
        local ok, err = pcall(function()
            local view = E.view(id,admin)
            menu.name = escape(title)
            menu.css = {top=Config.Phone.Position,header_color=Config.Phone.Color}
            menu.onclose = function(closing)
                if handingOff[closing] then handingOff[closing] = nil return end
                if back and E.uid(closing) == id then back(closing) end
            end
            if back then
                menu['↩ رجوع'] = {function(current)
                    if permitted(current,id,admin) then back(current) end
                end,'العودة إلى القائمة السابقة'}
            else
                menu['إغلاق القائمة'] = {function(current)
                    if permitted(current,id,admin) then vRP.closeMenu({current}) end
                end,'إغلاق قائمة الفعاليات'}
            end
            build(menu,view)
            vRP.openMenu({player,menu})
        end)
        if not ok then E.diagnostic('تعذر فتح قائمة الجوال.',err) end
    end})
end

local function operation(player,id,admin,action,data,fields,confirm,after)
    if not permitted(player,id,admin) then return end
    local function submit()
        if not permitted(player,id,admin) then return end
        local ok,message = E.perform(player,action,data)
        if E.uid(player) ~= id then return end
        E.notify(player,message,ok and 'success' or 'error')
        if after then after(player) end
    end
    local function collect(index)
        if not permitted(player,id,admin) then return end
        local field = fields and fields[index]
        if field then
            vRP.prompt({player,field[2],field[3] == 'flag' and (data[field[1]] and '1' or '0') or tostring(data[field[1]] or ''),function(who,value)
                if who ~= player or not permitted(who,id,admin) or type(value) ~= 'string' then return end
                if field[3] == 'flag' then data[field[1]] = value == '1' else data[field[1]] = value end
                collect(index+1)
            end})
        elseif confirm then
            vRP.request({player,'تأكيد: ' .. L.actions[action] .. '؟',20,function(who,accepted)
                if who == player and accepted then submit() end
            end})
        else submit() end
    end
    collect(1)
end

local actionFields = {
    saveTemplate={{'label','اسم القالب'}},
    schedule={{'minutes','الوقت حتى فتح التسجيل بالدقائق'}}, extend={{'minutes','دقائق التمديد'}},
    invite={{'target','رقم حساب اللاعب'}}, admit={{'target','رقم حساب اللاعب'}},
    team={{'team','رقم الفريق'}}, move={{'team','رقم الفريق'}},
    ban={{'target','رقم حساب اللاعب'},{'hours','مدة التقييد بالساعات، 0 للإزالة'}},
    review={{'outcome','done = تم التسليم، charged = تم الخصم، clear = لم ينفذ'}}
}
local confirm = {delete=true,stop=true,cancel=true,kick=true,refund=true,claim=true,buy=true,ban=true,review=true,automatic=true}
local function eventFields(view)
    local modes,prizes = {},{}
    for key,label in pairs(view.modes) do modes[#modes+1] = key .. ' = ' .. label end
    for key,label in pairs(view.prizes) do prizes[#prizes+1] = key .. ' = ' .. label end
    local fields = {{'name','اسم الفعالية'}, {'description','الوصف'}, {'rules','شروط وقواعد المشاركة'},
        {'category','التصنيف'}, {'mode',table.concat(modes,'، ')}, {'minimum','الحد الأدنى للمشاركين'},
        {'maximum','الحد الأقصى للمشاركين'}, {'registration','مدة التسجيل بالثواني'},
        {'duration','مدة اللعب بالثواني'}, {'countdown','مدة العد التنازلي بالثواني'},
        {'teams','عدد الفرق، 0 لتعطيل الفرق'}, {'permission','صلاحية المشاركة، اتركها فارغة للجميع'},
        {'private','خاصة بالدعوات؟ 1 نعم، 0 لا','flag'}, {'autostart','تشغيل تلقائي؟ 1 نعم، 0 لا','flag'}}
    if view.economy then
        fields[#fields+1] = {'fee','الرسوم النقدية'}
        fields[#fields+1] = {'reward',table.concat(prizes,'، ')}
    end
    return fields
end

local function eventDescription(event)
    return escape(event.locked and event.state == 'registration' and 'استقبال التسجيلات متوقف' or L.state[event.state]) .. ' | ' .. escape(L.mode[event.mode]) .. '<br>' ..
        escape(event.description) .. '<br>الشروط: ' .. escape(event.rules) ..
        '<br>المشاركون: ' .. event.count .. '/' .. event.maximum .. ' | الرسوم: ' .. event.fee ..
        '<br>الجائزة: ' .. escape(event.prize)
end

openEvent = function(player,id,admin,eventId,back)
    menuFor(player,id,admin,'slom_events_event','تفاصيل الفعالية',back,function(menu,view)
        local event
        for _, row in ipairs(view.events) do if row.id == eventId then event = row break end end
        if not event then return end
        local function refresh(who) openEvent(who,id,admin,eventId,back) end
        menu['#' .. event.id .. ' ' .. escape(event.name)] = {refresh,eventDescription(event)}
        for _, action in ipairs(event.actions) do
            menu[L.actions[action]] = {function(who)
                local data = action == 'edit' and E.copy(event.form) or {}
                data.event = event.id
                operation(who,id,admin,action,data,action == 'edit' and eventFields(view) or actionFields[action],
                    confirm[action],action == 'delete' and back or refresh)
            end,eventDescription(event)}
        end
        if event.question then
            for index, option in ipairs(event.question.options) do
                menu['إجابة ' .. index .. ' | ' .. escape(option)] = {function(who)
                    operation(who,id,admin,'answer',{event=event.id,question=event.question.index,option=index},nil,false,refresh)
                end,escape(event.question.text)}
            end
        end
        for _, member in ipairs(event.members or {}) do
            menu['مشارك #' .. member.id .. ' | ' .. escape(member.name)] = {function(who)
                menuFor(who,id,admin,'slom_events_member','إدارة المشارك',refresh,function(sub)
                    for _, action in ipairs(member.actions) do
                        sub[L.actions[action]] = {function(current)
                            operation(current,id,admin,action,{event=event.id,target=member.id},actionFields[action],confirm[action],refresh)
                        end,'حساب المشارك #' .. member.id}
                    end
                end)
            end,(L.status[member.status] or '') .. '<br>الفريق: ' .. (member.team or '—') .. ' | النتيجة: ' .. (member.score or 0)}
        end
    end)
end

local function submenu(player,id,admin,title,back,build)
    menuFor(player,id,admin,'slom_events_section',title,back,build)
end

openRoot = function(player,admin)
    local id = E.uid(player)
    local title = admin and Config.Phone.AdminTitle or Config.Phone.PlayerTitle
    local function root(who) openRoot(who,admin) end
    menuFor(player,id,admin,admin and 'slom_events_admin' or 'slom_events_player',title,nil,function(menu,view)
        if E.tabletAllowed(id,admin and 'admin' or 'player') then
            menu['فتح التابلت'] = {function(who)
                if not permitted(who,id,admin) or not E.tabletAllowed(id,admin and 'admin' or 'player') then return end
                handingOff[who] = true
                SetTimeout(1500,function() handingOff[who] = nil end)
                vRP.closeMenu({who})
                E.tabletOpen(who,admin and 'admin' or 'player')
            end,'عرض الواجهة الموسعة'}
        end
        local function list(label, predicate, help)
            local function section(who)
                submenu(who,id,admin,label,root,function(sub,current)
                    for _, event in ipairs(current.events) do
                        if predicate(event) then
                            sub['#' .. event.id .. ' ' .. escape(event.name)] = {function(target)
                                openEvent(target,id,admin,event.id,section)
                            end,eventDescription(event)}
                        end
                    end
                end)
            end
            menu[label] = {section,help}
        end
        if admin then
            list('إدارة الفعاليات',function() return true end,'إدارة المسودات والتسجيل والفرق والنتائج')
            if E.has(id,'Create') then
                menu['إنشاء فعالية'] = {function(who)
                    local data = E.copy(view.defaults)
                    data.mode,data.teams,data.fee,data.reward = view.modes.manual and 'manual' or next(view.modes),0,0,'none'
                    operation(who,id,true,'create',data,eventFields(view),false,root)
                end,'حفظ فعالية جديدة كمسودة'}
            end
            if view.pages.templates then
                menu['القوالب المحفوظة'] = {function(who)
                    submenu(who,id,true,'القوالب المحفوظة',root,function(sub,current)
                        for _, template in ipairs(current.templates) do
                            if current.useTemplate then
                                sub['استخدام #' .. template.key .. ' | ' .. escape(template.label)] = {function(p)
                                    operation(p,id,true,'useTemplate',{key=template.key},nil,true,root)
                                end,'إنشاء مسودة من القالب'}
                            end
                            if current.deleteTemplate then
                                sub['حذف #' .. template.key .. ' | ' .. escape(template.label)] = {function(p)
                                    operation(p,id,true,'deleteTemplate',{key=template.key},nil,true,root)
                                end,'حذف القالب المحفوظ'}
                            end
                        end
                    end)
                end,'إنشاء مسودة من إعدادات محفوظة'}
            end
            if view.controlBan then
                menu['تقييد المشاركة'] = {function(who) operation(who,id,true,'ban',{},actionFields.ban,true,root) end,'تقييد حساب لمدة محددة'}
            end
            if view.controlAutomatic then
                menu['الجدولة التلقائية'] = {function(who) operation(who,id,true,'automatic',{},nil,true,root) end,
                    view.automatic and 'مفعلة' or 'متوقفة'}
            end
            if E.has(id,'Rewards') then
                menu['مراجعة عمليات الجوائز'] = {function(who)
                    submenu(who,id,true,'مراجعة عمليات الجوائز',root,function(sub,current)
                        for _, row in ipairs(current.reviews) do
                            sub[escape(row.label) .. ' | ' .. row.key] = {function(p)
                                operation(p,id,true,'review',{key=row.key},actionFields.review,true,root)
                            end,'الحساب #' .. row.id .. ' | القيمة: ' .. row.amount}
                        end
                    end)
                end,'تسوية العمليات المعلقة بعد التحقق من السجلات'}
            end
            if E.has(id,'Logs') then
                menu['السجلات الإدارية'] = {function(who)
                    submenu(who,id,true,'السجلات الإدارية',root,function(sub,current)
                        for i,row in ipairs(current.logs) do
                            if i > 25 then break end
                            sub[i .. ' | ' .. escape(row.action)] = {function() end,
                                os.date('!%Y-%m-%d %H:%M',row.at) .. ' UTC<br>المنفذ: ' .. escape(row.actor or 'النظام') ..
                                '<br>الفعالية: ' .. escape(row.name or '—')}
                        end
                    end)
                end,'عرض أحدث 25 عملية'}
            end
        else
            list('الفعاليات المتاحة',function(e) return e.state == 'registration' end,'التسجيل أو اختيار الفريق أو دعوة لاعب')
            list('الفعاليات الجارية',function(e) return e.state == 'countdown' or e.state == 'running' end,'عرض الحالة والإجابة عن الأسئلة')
            list('فعالياتي والفعاليات القادمة',function(e) return e.state == 'scheduled' or e.status ~= nil end,'عرض التسجيلات والمواعيد')
            list('سجل مشاركاتي',function(e) return e.status and (e.state == 'completed' or e.state == 'cancelled') end,'عرض المشاركات السابقة والنتائج')
            local p = view.profile
            menu['الإعدادات الشخصية'] = {function(who)
                operation(who,id,false,'preferences',{mute=not p.muteAnnouncements},nil,true,root)
            end,p.muteAnnouncements and 'الإعلانات مكتومة. اختر لإعادة تشغيلها.' or 'الإعلانات مفعلة. اختر لكتمها.'}
            menu['نقاطي ومستواي'] = {root,('نقاط: %s | مستوى: %s | خبرة: %s<br>فوز: %s | مشاركات: %s'):format(p.points,p.level,p.xp,p.wins,p.games)}
            menu['الجوائز المتاحة'] = {function(who)
                submenu(who,id,false,'الجوائز',root,function(sub,current)
                    for _, row in ipairs(current.rewards) do
                        sub[escape(row.label) .. ' | ' .. row.key] = {function(p)
                            if row.status == 'pending' then operation(p,id,false,'claim',{key=row.key},nil,true,root) end
                        end,L.status[row.status] .. ' | ' .. row.amount}
                    end
                end)
            end,'عرض واستلام الجوائز'}
            menu['متجر النقاط'] = {function(who)
                submenu(who,id,false,'متجر النقاط',root,function(sub,current)
                    for _, row in ipairs(current.market) do
                        sub[escape(row.label)] = {function(p)
                            if not row.owned and row.stock > 0 then operation(p,id,false,'buy',{key=row.key},nil,true,root) end
                        end,('السعر: %s | المتبقي: %s'):format(row.price,row.stock)}
                    end
                end)
            end,'استبدال النقاط بالألقاب'}
            menu['ترتيب اللاعبين'] = {function(who)
                submenu(who,id,false,'ترتيب الموسم',root,function(sub,current)
                    for i,row in ipairs(current.ranking) do
                        if i > 25 then break end
                        sub[i .. ' | حساب #' .. row.id] = {function() end,'خبرة الموسم: ' .. row.seasonXP .. ' | الانتصارات: ' .. row.wins}
                    end
                end)
            end,'عرض أفضل 25 لاعباً'}
        end
    end)
end

RegisterCommand(Config.Phone.PlayerCommand or 'eventsphone',function(player)
    if player > 0 then openRoot(player,false) end
end,false)

RegisterCommand(Config.Phone.AdminCommand or 'eventsphoneadmin',function(player)
    if player > 0 then openRoot(player,true) end
end,false)

if not Config.Phone.Enabled or Config.Phone.ParentIntegration == false then return end
local parents = {}
local function attach(parent, mode)
    parents[parent] = parents[parent] or {}
    parents[parent][mode] = true
end
attach(Config.Phone.PlayerParent,'player')
attach(Config.Phone.AdminParent,'admin')
if Config.Phone.Fallback then attach('main','admin') end

for parent,modes in pairs(parents) do
    local marker = 'slom_events:phone:' .. parent
    if Config.Phone.Enabled and GetConvar(marker,'') == '' then
        vRP.registerMenuBuilder({parent,function(add,data)
            local choices = {}
            local player = data and data.player
            local id = E.uid(player)
            if GetResourceState(resource) == 'started' and id then
                if modes.player and permitted(player,id,false) then
                    choices[Config.Phone.PlayerTitle] = {function(who) openRoot(who,false) end,'عرض الفعاليات والتسجيل والجوائز'}
                end
                if modes.admin and permitted(player,id,true) then
                    choices[Config.Phone.AdminTitle] = {function(who) openRoot(who,true) end,'إدارة نظام الفعاليات'}
                end
            end
            add(choices)
        end})
        SetConvar(marker,'installed')
    end
end
