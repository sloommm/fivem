E.games = {}

E.games.manual = {
    resolve = function(event, eligible)
        for _, id in ipairs(eligible) do
            if id == event.selected then return id end
        end
    end
}

E.games.draw = {
    resolve = function(_, eligible)
        if #eligible > 0 then return eligible[math.random(#eligible)] end
    end
}

function E.question(event, now)
    if event.mode ~= 'quiz' or event.state ~= 'running' then return end
    return math.floor((now - event.started) * #Server.Quiz / event.duration) + 1
end

E.games.quiz = {
    answer = function(event, participant, data, now)
        local index = E.question(event, now)
        local question = Server.Quiz[index]
        local option = tonumber(data.option)
        participant.answers = participant.answers or {}
        if not question or tonumber(data.question) ~= index or participant.answers[tostring(index)]
            or not option or not question.options[option] then return false end
        participant.answers[tostring(index)] = option
        if option == question.correct then participant.score = (participant.score or 0) + 1 end
        return true
    end,
    resolve = function(event, eligible)
        local winner, best = nil, 0
        for _, id in ipairs(eligible) do
            local score = event.members[id].score or 0
            if score > best then winner, best = id, score end
        end
        return winner
    end
}
