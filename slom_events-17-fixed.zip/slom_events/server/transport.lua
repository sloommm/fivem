local R = 'slom_events:'
local viewRate, controlRate = {}, {}
local hud = {}

function E.tabletAllowed(id, mode)
    if not Config.Tablet.Enabled or not id then return false end
    if mode == 'admin' then return Config.Tablet.AdminAccess and E.has(id,'OpenAdmin') end
    return mode == 'player' and Config.Tablet.PlayerAccess
end

function E.tabletOpen(player, mode)
    if E.tabletAllowed(E.uid(player),mode) then
        TriggerClientEvent(R .. 'openTablet',player,mode)
    else
        E.notify(player,L.denied,'error')
    end
end

function E.view(id, admin)
    local state, now = E.state, os.time()
    local all, rewards, market, ranking, reviews = {}, {}, {}, {}, {}
    local day, week, season = E.periods(state,now)
    local p = E.copy(state.players[id] or E.newProfile())
    p.level = math.floor(p.xp / Server.Progress.PerLevel) + 1
    p.daily = p.day == day and p.daily or 0
    p.weekly = p.week == week and p.weekly or 0
    if p.season and p.season ~= season then
        p.archives = p.archives or {}
        p.archives[tostring(p.season)] = p.seasonXP
        p.seasonXP = 0
    end
    p.badges = {}
    if p.games > 0 then p.badges[#p.badges+1] = 'أول مشاركة' end
    if p.wins > 0 then p.badges[#p.badges+1] = 'أول فوز' end
    if p.streak >= 3 then p.badges[#p.badges+1] = 'ثلاثة انتصارات متتالية' end
    p.dailyGoal, p.weeklyGoal = Server.Progress.DailyGoal, Server.Progress.WeeklyGoal
    p.ban, p.day, p.week = nil, nil, nil

    for _, event in pairs(state.events) do
        if E.canSee(event,id,admin) then
            local item = {
                id=event.id, name=event.name, description=event.description, category=event.category, rules=event.rules,
                state=event.state, mode=event.mode, count=E.countMembers(event,'joined'), maximum=event.maximum,
                minimum=event.minimum, fee=event.fee, teams=event.teams, deadline=event.deadline,
                scheduled=event.scheduled, locked=event.locked, winner=event.winner, prize=event.prize.label, actions={}
            }
            local member = event.members[id]
            item.status = member and member.status
            local function action(name, condition)
                if condition and (not E.permissions[name] or (admin and E.has(id,E.permissions[name]))) then
                    item.actions[#item.actions+1] = name
                end
            end
            local joined = member and member.status == 'joined'
            local open = event.state == 'registration'
            local running = event.state == 'running'
            local active = open or running or event.state == 'countdown'
            local draft = event.state == 'draft'
            local scheduled = event.state == 'scheduled'
            if not admin then
                action('join',open and not event.locked and now < event.deadline and (not member or (member.status=='left' and not member.paid)))
                action('promote',open and not event.locked and member and member.status == 'wait' and item.count < event.maximum)
                action('leave',active and member and (joined or member.status == 'wait'))
                action('invite',open and joined)
                action('team',open and joined and event.teams > 0)
                local questionIndex = running and E.question(event,now)
                if joined and questionIndex and Server.Quiz[questionIndex] and
                    not (member.answers and member.answers[tostring(questionIndex)]) then
                    local question = Server.Quiz[questionIndex]
                    item.question = {index=questionIndex,text=question.text,options=question.options}
                end
                item.score = member and member.score
            else
                action('edit',draft)
                action('delete',draft or scheduled)
                action('publish',draft or scheduled)
                action('schedule',draft or scheduled)
                action('clone',true)
                action('saveTemplate',true)
                action('start',open)
                action('stop',running)
                action('cancel',active or scheduled)
                action('extend',open)
                action('lock',open and not event.locked and now < event.deadline)
                action('unlock',open and event.locked and now < event.deadline)
                action('announce',active and not event.private and event.permission == '')
                action('admit',open)
                if draft and E.has(id,'Edit') then
                    item.form = {name=event.name, description=event.description, rules=event.rules, category=event.category,
                        mode=event.mode, minimum=event.minimum, maximum=event.maximum, registration=event.registration,
                        duration=event.duration, countdown=event.countdown, fee=event.fee, teams=event.teams,
                        permission=event.permission, private=event.private, autostart=event.autostart, reward=event.reward}
                end
                if E.has(id,'ManagePlayers') then
                    item.members = {}
                    for target, participant in pairs(event.members) do
                        local allowed = {}
                        if active and (participant.status == 'joined' or participant.status == 'wait') and E.has(id,'Kick') then allowed[#allowed+1] = 'kick' end
                        if open and participant.status == 'joined' and event.teams > 0 and E.has(id,'ManageTeams') then allowed[#allowed+1] = 'move' end
                        if running and participant.status == 'joined' and event.mode == 'manual' and E.has(id,'SetWinner') then allowed[#allowed+1] = 'winner' end
                        if participant.paid and not participant.refunded and E.has(id,'Refund') then allowed[#allowed+1] = 'refund' end
                        item.members[#item.members+1] = {id=target,name=participant.name,status=participant.status,
                            team=participant.team,score=participant.score,actions=allowed}
                    end
                    table.sort(item.members,function(a,b) return tonumber(a.id)<tonumber(b.id) end)
                end
            end
            all[#all+1] = item
        end
    end
    table.sort(all,function(a,b) return tonumber(a.id)>tonumber(b.id) end)
    for key, reward in pairs(state.ledger) do
        if reward.id == id and reward.kind ~= 'fee' then
            rewards[#rewards+1] = {key=key,event=reward.event,label=reward.label,status=reward.status,amount=reward.amount}
        end
        if admin and E.has(id,'Rewards') and reward.status == 'applying' then
            reviews[#reviews+1] = {key=key,event=reward.event,label=reward.label,id=reward.id,amount=reward.amount,kind=reward.kind}
        end
    end
    for key, item in pairs(Server.Store.Enabled and Server.Store.Items or {}) do
        market[#market+1] = {key=key,label=item.label,price=item.price,stock=item.stock-(state.purchases[key] or {count=0}).count,
            owned=p.titles[key] ~= nil}
    end
    for user, other in pairs(state.players) do
        if other.games > 0 then ranking[#ranking+1] = {id=user,xp=other.xp,wins=other.wins,seasonXP=other.season == season and other.seasonXP or 0} end
    end
    table.sort(ranking,function(a,b)
        if a.seasonXP ~= b.seasonXP then return a.seasonXP>b.seasonXP end
        if a.xp ~= b.xp then return a.xp>b.xp end
        return tonumber(a.id)<tonumber(b.id)
    end)
    local leaders = {}
    if Config.Pages.leaders then
        leaders = E.copy(ranking)
        table.sort(leaders,function(a,b)
            if a.xp ~= b.xp then return a.xp>b.xp end
            if a.wins ~= b.wins then return a.wins>b.wins end
            return tonumber(a.id)<tonumber(b.id)
        end)
        while #leaders > 100 do table.remove(leaders) end
    end
    while #ranking > 100 do table.remove(ranking) end
    local page = {}
    for key,value in pairs(Config.Pages) do page[key] = value end
    page.create = page.create and admin and E.has(id,'Create')
    page.manage = page.manage and admin
    page.participants = page.participants and admin and E.has(id,'ManagePlayers')
    page.teams = page.teams and admin and E.has(id,'ManagePlayers') and E.has(id,'ManageTeams')
    page.schedule = page.schedule and admin and (E.has(id,'Schedule') or E.has(id,'Automatic'))
    page.templates = page.templates and admin and (E.has(id,'Create') or E.has(id,'Delete'))
    page.logs = page.logs and admin and E.has(id,'Logs')
    page.system = page.system and admin and E.has(id,'Diagnostics')
    local modes, prizes = {}, {}
    for key,value in pairs(Server.Games) do if value then modes[key] = L.mode[key] end end
    for key,value in pairs(Server.Economy.Rewards) do
        if key == 'none' or Server.Economy.Enabled then prizes[key] = value.label end
    end
    local templates, schedules = {}, {}
    if page.templates then
        for key, template in pairs(state.templates) do
            templates[#templates+1] = {key=key,label=template.label,name=template.options.name,mode=template.options.mode}
        end
    end
    if page.schedule then
        for _, entry in ipairs(Server.Automatic.Entries) do
            schedules[#schedules+1] = {name=entry.name,hour=entry.hour,minute=entry.minute,
                weekday=entry.weekday,online=entry.online,mode=entry.mode}
        end
    end
    return {leaders=leaders,news=page.announcements and state.news or {},templates=templates,schedules=schedules, scheduleOffset=page.schedule and Server.Automatic.OffsetMinutes,
        useTemplate=page.templates and E.has(id,'Create'),deleteTemplate=page.templates and E.has(id,'Delete'),events=all,profile=p,rewards=rewards,market=market,ranking=ranking,reviews=reviews,pages=page,
        logs=page.logs and state.logs or {}, system=page.system and {revision=E.revision,automatic=state.automatic} or nil,
        controlAutomatic=admin and E.has(id,'Automatic'), automatic=admin and E.has(id,'Automatic') and state.automatic,
        controlBan=admin and E.has(id,'Ban'), defaults=Server.Defaults, modes=modes, prizes=prizes,
        states=L.state, statuses=L.status, actions=L.actions, name=Config.Name,
        logo=Config.Logo:match('^[%w_.%-]+$') and Config.Logo or '', credit=Config.Credit,
        economy=Server.Economy.Enabled, animations=Config.Tablet.Animations, now=now, season=season, admin=admin,
        otherTablet=E.tabletAllowed(id,admin and 'player' or 'admin')}
end

RegisterNetEvent(R .. 'rpc',function(token,mode,action,data)
    local player = source
    if type(token) ~= 'number' or token < 1 or token > 2147483647 or token%1 ~= 0 then return end
    local id = E.uid(player)
    if not id then return end
    local now = GetGameTimer()
    if viewRate[player] and now-viewRate[player] < 180 then
        TriggerClientEvent(R .. 'result',player,token,false,L.busy)
        return
    end
    viewRate[player] = now
    local ok, message, view
    if not E.tabletAllowed(id,mode) then
        TriggerClientEvent(R .. 'forceClose',player)
        ok,message = false,L.denied
    elseif not E.ready then ok,message = false,L.offline
    elseif action == 'view' then ok = true
    elseif mode ~= 'admin' and type(action) == 'string' and E.permissions[action] then ok,message = false,L.denied
    else ok,message = E.perform(player,action,data) end
    if id ~= E.uid(player) then return end
    if ok and E.ready and E.tabletAllowed(id,mode) then
        local built,result = pcall(E.view,id,mode == 'admin')
        if built then view = result else E.diagnostic('تعذر إنشاء بيانات الواجهة.',result) ok,message = false,L.offline end
    end
    TriggerClientEvent(R .. 'result',player,token,ok == true,message,view)
end)

local function registerTabletCommand(command, mode)
    RegisterCommand(command,function(player)
        if player > 0 then E.tabletOpen(player,mode) end
    end,false)
end
registerTabletCommand(Config.Tablet.Command,'player')
registerTabletCommand(Config.Tablet.AdminCommand,'admin')
local function canControl(player)
    local now = GetGameTimer()
    if controlRate[player] and now - controlRate[player] < 350 then return false end
    controlRate[player] = now
    return true
end
RegisterNetEvent(R .. 'switchTablet',function(mode)
    if not canControl(source) then return end
    if mode == 'player' then E.tabletOpen(source,'admin')
    elseif mode == 'admin' then E.tabletOpen(source,'player') end
end)
RegisterNetEvent(R .. 'settingsRequest',function()
    if not canControl(source) then return end
    TriggerClientEvent(R .. 'settings',source,Config.Tablet.Command,Config.Tablet.Key,Config.Tablet.CloseOnDeath)
end)

RegisterCommand('eventsdiag',function(player)
    local message = ('الخدمة: %s | قاعدة البيانات: %s'):format(GetCurrentResourceName(),E.ready and 'متصلة' or 'غير متاحة')
    if player == 0 then print(message) return end
    local id = E.uid(player)
    if E.has(id,'OpenAdmin') and E.has(id,'Diagnostics') then E.notify(player,message) end
end,false)

function E.pushHud()
    local nextHud = {}
    if Config.Tablet.Hud and E.ready then
        for _, event in pairs(E.state.events) do
            if event.state == 'countdown' or event.state == 'running' then
                local count = E.countMembers(event,'joined')
                for id, member in pairs(event.members) do
                    local player = member.status == 'joined' and E.source(id)
                    if player then
                        nextHud[player] = id
                        local seconds = math.max(0,event.deadline-os.time())
                        TriggerClientEvent(R .. 'hud',player,{name=event.name,state=L.state[event.state],
                            seconds=seconds,score=member.score or 0,team=member.team,
                            count=count})
                    end
                end
            end
        end
    end
    for player,id in pairs(hud) do
        if not nextHud[player] and E.uid(player) == id then TriggerClientEvent(R .. 'hud',player,false) end
    end
    hud = nextHud
end

AddEventHandler('playerDropped',function()
    viewRate[source],hud[source],controlRate[source] = nil,nil,nil
end)
