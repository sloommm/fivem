local permissions = {
    create='Create', clone='Create', saveTemplate='Create', useTemplate='Create', deleteTemplate='Delete', edit='Edit', publish='Edit', extend='Edit', lock='Edit', unlock='Edit', delete='Delete',
    start='Start', stop='Stop', cancel='Cancel', kick='Kick', move='ManageTeams', ban='Ban',
    winner='SetWinner', admit='ManagePlayers', announce='Announce', refund='Refund', schedule='Schedule',
    automatic='Automatic', review='Rewards'
}
E.permissions = permissions

local function integer(value, minimum, maximum)
    if type(value) ~= 'number' and type(value) ~= 'string' then return nil end
    local number = math.tointeger(tonumber(value))
    if number and number >= minimum and number <= maximum then return number end
    return nil
end

local function short(value, size, required)
    if type(value) ~= 'string' or #value > size or not utf8.len(value) or value:find('%c') then return end
    value = value:match('^%s*(.-)%s*$')
    if required and value == '' then return end
    return value
end

local function isActive(event)
    return event.state == 'registration' or event.state == 'countdown' or event.state == 'running'
end

local function activeCount(state)
    local count = 0
    for _, event in pairs(state.events) do if isActive(event) then count = count + 1 end end
    return count
end

local function countMembers(event, status)
    local count = 0
    for _, member in pairs(event.members) do if member.status == status then count = count + 1 end end
    return count
end
E.countMembers = countMembers

local function newProfile()
    return {xp=0, points=0, games=0, wins=0, streak=0, daily=0, weekly=0, seasonXP=0, titles={}}
end
E.newProfile = newProfile

local function profile(state, id)
    state.players[id] = state.players[id] or newProfile()
    return state.players[id]
end

function E.periods(state, now)
    local offset = now + Server.Automatic.OffsetMinutes * 60
    return math.floor(offset / 86400), math.floor((offset + 3 * 86400) / 604800),
        math.floor((now - state.created) / (Server.Progress.SeasonDays * 86400)) + 1
end

local function eligible(event)
    local list = {}
    for id, member in pairs(event.members) do
        if member.status == 'joined' and E.source(id) then list[#list+1] = id end
    end
    table.sort(list, function(a,b)
        if event.members[a].order == event.members[b].order then return tonumber(a) < tonumber(b) end
        return event.members[a].order < event.members[b].order
    end)
    return list
end

function E.canSee(event, id, admin)
    if admin then return true end
    if event.state == 'draft' or (event.state == 'scheduled' and event.private) then return false end
    local allowed = not event.private or event.members[id] or event.invites[id]
    return allowed and (event.permission == '' or E.vrp.hasPermission({tonumber(id), event.permission}) == true)
end

local function audit(state, id, action, event, target)
    local log = { at=os.time(), actor=id, action=L.actions[action] or action, event=event and event.id, 
        name=event and event.name, target=target }
    local player = id and E.source(id)
    if player then log.actorName = short(E.vrp.getPlayerName({player}), 100) end
    table.insert(state.logs, 1, log)
    while #state.logs > Server.Limits.Logs do table.remove(state.logs) end
    return log
end

local function ledger(state, key, id, event, reward)
    state.ledger[key] = {id=id, event=event.id, label=reward.label, kind=reward.kind,
        amount=reward.amount, item=reward.item, status='pending'}
end

local function refund(state, event, id)
    local member = event.members[id]
    if not member or not member.paid or member.refunded then return false end
    ledger(state, ('refund:%s:%s'):format(event.id, id), id, event,
        {label='استرداد رسوم المشاركة',kind='cash',amount=member.paid})
    member.refunded = true
    return true
end

local function finish(state, event, now, cancelled)
    event.finished = now
    event.state = cancelled and 'cancelled' or 'completed'
    event.deadline = nil
    if cancelled then
        for id in pairs(event.members) do refund(state,event,id) end
        return
    end
    local list = eligible(event)
    local winner = E.games[event.mode].resolve(event, list)
    event.winner = winner
    local day, week, season = E.periods(state, now)
    for _, id in ipairs(list) do
        local p = profile(state, id)
        if p.day ~= day then p.day, p.daily = day, 0 end
        if p.week ~= week then p.week, p.weekly = week, 0 end
        if p.season ~= season then
            p.archives = p.archives or {}
            if p.season then p.archives[tostring(p.season)] = p.seasonXP end
            p.season, p.seasonXP = season, 0
        end
        p.games, p.weekly = p.games + 1, p.weekly + 1
        p.daily = p.daily + 1
        local won = id == winner
        p.streak = won and p.streak + 1 or 0
        if won then p.wins = p.wins + 1 end
        if p.daily <= Server.Progress.Daily then
            local xp = Server.Progress.XP + (won and Server.Progress.WinXP or 0)
            p.xp, p.seasonXP = p.xp + xp, p.seasonXP + xp
            if won then p.points = p.points + Server.Progress.Points end
        end
    end
    if winner and event.prize.kind ~= 'none' then
        ledger(state, 'prize:' .. event.id, winner, event, event.prize)
    end
end

local function teamFor(event)
    if event.teams == 0 then return end
    local counts, best = {}, 1
    for i = 1, event.teams do counts[i] = 0 end
    for _, member in pairs(event.members) do
        if member.status == 'joined' and member.team then
            counts[member.team] = counts[member.team] + 1
        end
    end
    for i = 2, event.teams do if counts[i] < counts[best] then best = i end end
    return best
end

local function promote(event)
    if event.locked or event.fee > 0 or countMembers(event, 'joined') >= event.maximum then return end
    local candidate
    for id, member in pairs(event.members) do
        if member.status == 'wait' and E.source(id) and (not candidate or member.order < candidate.order) then
            candidate = member
        end
    end
    if candidate then
        candidate.team, candidate.status = teamFor(event), 'joined'
        return true
    end
end

local function form(data)
    local defaults = Server.Defaults
    local name = short(data.name, 90, true)
    local description = short(data.description or '', 320)
    local rules = short(data.rules or '', 320)
    local category = short(data.category or '', 65)
    local permission = short(data.permission or '', 80)
    local mode = type(data.mode) == 'string' and data.mode or 'manual'
    local minimum = integer(data.minimum or defaults.minimum, 1, Server.Limits.Participants)
    local maximum = integer(data.maximum or defaults.maximum, 1, Server.Limits.Participants)
    local registration = integer(data.registration or defaults.registration, 30, Server.Limits.Registration)
    local duration = integer(data.duration or defaults.duration, 10, Server.Limits.Duration)
    local countdown = integer(data.countdown or defaults.countdown, 1, 120)
    local fee = integer(data.fee or 0, 0, Server.Economy.Enabled and Server.Limits.Fee or 0)
    local teams = integer(data.teams or 0, 0, 8)
    local reward = Server.Economy.Rewards[data.reward or 'none']
    if not name or not description or not rules or not category or not permission or not Server.Games[mode]
        or not E.games[mode] or not minimum or not maximum or minimum > maximum or not registration
        or not duration or not countdown or not fee or not teams or teams == 1 or not reward
        or (mode == 'quiz' and duration < #Server.Quiz * 3) then return end
    if reward.kind ~= 'none' and (not Server.Economy.Enabled or not integer(reward.amount,1,Server.Economy.Max)
        or (reward.kind ~= 'cash' and reward.kind ~= 'bank' and reward.kind ~= 'item')
        or (reward.kind == 'item' and type(reward.item) ~= 'string')) then return end
    if permission ~= '' and not permission:match('^[%w_.%-]+$') then return end
    return {name=name, description=description, rules=rules, category=category, permission=permission,
        mode=mode, minimum=minimum, maximum=maximum, registration=registration, duration=duration,
        countdown=countdown, fee=fee, teams=teams, private=data.private == true,
        autostart=data.autostart == true, reward=data.reward or 'none', prize=E.copy(reward)}
end

local function insertEvent(state, options, now)
    local count = 0
    for _ in pairs(state.events) do count = count + 1 end
    if count >= Server.Limits.EventCount then return end
    state.nextEvent = state.nextEvent + 1
    local id = tostring(state.nextEvent)
    options.id, options.created, options.state = id, now, 'draft'
    options.members, options.invites, options.sequence = {}, {}, 0
    state.events[id] = options
    return options
end

local function recordNews(state, message, now)
    state.news = state.news or {}
    table.insert(state.news,1,{message=message,at=now})
    while #state.news > 50 do table.remove(state.news) end
end

local function announce(message)
    for _, sourceId in pairs(GetPlayers()) do
        local player = tonumber(sourceId)
        local id = E.uid(player)
        local p = id and E.state.players[id]
        if id and (not p or not p.muteAnnouncements) then E.notify(player,Config.Name .. ' | ' .. message) end
    end
end

local function openRegistration(event, now)
    event.state = 'registration'
    event.deadline = now + event.registration
end

local function initialized(id)
    return type(E.vrp.getUserDataTable({tonumber(id)})) == 'table'
        and type(E.vrp.getUserTmpTable({tonumber(id)})) == 'table'
end

local function canGrant(id, entry)
    if not Server.Economy.Enabled or not initialized(id) or not integer(entry.amount,1,Server.Economy.Max) then return false end
    if entry.kind == 'cash' or entry.kind == 'bank' then return true end
    if entry.kind ~= 'item' or type(entry.item) ~= 'string' then return false end
    local name = E.vrp.getItemDefinition({entry.item})
    local weight = E.vrp.getItemWeight({entry.item})
    local carried = E.vrp.getInventoryWeight({tonumber(id)})
    local capacity = E.vrp.getInventoryMaxWeight({tonumber(id)})
    return name and type(weight) == 'number' and weight >= 0 and type(carried) == 'number'
        and type(capacity) == 'number' and carried + entry.amount * weight <= capacity
end

local function claim(state, id, player, key)
    local entry = state.ledger[key]
    if not entry or entry.id ~= id or entry.kind == 'fee' then return false, L.invalid end
    if entry.status == 'applying' then return false, L.review end
    if entry.status ~= 'pending' then return false, L.invalid end
    if not canGrant(id, entry) then return false, L.space end
    entry.status = 'applying'
    if not E.persist(state) then return false, L.offline end
    local final = E.copy(E.state)
    entry = final.ledger[key]
    if E.uid(player) ~= id or not canGrant(id, entry) then
        entry.status = 'pending'
        E.persist(final)
        return false, L.space
    end
    if entry.kind == 'cash' then E.vrp.giveMoney({tonumber(id),entry.amount})
    elseif entry.kind == 'bank' then E.vrp.giveBankMoney({tonumber(id),entry.amount})
    else E.vrp.giveInventoryItem({tonumber(id),entry.item,entry.amount,true}) end
    entry.status = 'done'
    return final
end

local function charge(state, event, id, player, member)
    local key = ('fee:%s:%s'):format(event.id, id)
    if state.ledger[key] or not initialized(id) then return false, L.review end
    if (tonumber(E.vrp.getMoney({tonumber(id)})) or 0) < event.fee then return false, L.poor end
    local reserved = E.copy(E.state)
    ledger(reserved, key, id, event, {label='رسوم المشاركة',amount=event.fee,kind='fee'})
    reserved.ledger[key].status = 'applying'
    if not E.persist(reserved) then return false, L.offline end
    if E.uid(player) ~= id or os.time() >= event.deadline or not initialized(id)
        or not E.vrp.tryPayment({tonumber(id),event.fee}) then
        local final = E.copy(E.state)
        final.ledger[key] = nil
        E.persist(final)
        return false, L.poor
    end
    state.ledger[key] = E.copy(reserved.ledger[key])
    state.ledger[key].status = 'done'
    member.paid = event.fee
    return true
end

local function apply(state, action, data, player, id, now)
    local event = state.events[tostring(integer(data.event, 1, 2147483647))]
    local target = tostring(integer(data.target, 1, 2147483647))
    local member = event and event.members[id]
    local message, broadcast, recipient, notifyMessage
    if action == 'create' or action == 'clone' then
        local options
        if action == 'create' then options = form(data)
        elseif event then options = form(event) end
        if not options then return false, L.invalid end
        event = insertEvent(state, options, now)
        if not event then return false, L.invalid end
    elseif action == 'saveTemplate' then
        if not event then return false,L.invalid end
        local name = short(data.label,90,true)
        local options = form(event)
        if not name or not options then return false,L.invalid end
        local count = 0
        for _ in pairs(state.templates) do count = count + 1 end
        if count >= Server.Limits.Templates then return false,L.invalid end
        local key = tostring(state.nextTemplate or 1)
        state.nextTemplate = tonumber(key) + 1
        state.templates[key] = {label=name,options=options}
    elseif action == 'useTemplate' or action == 'deleteTemplate' then
        local key = short(data.key,12)
        local template = key and state.templates[key]
        if not template then return false,L.invalid end
        if action == 'deleteTemplate' then
            state.templates[key] = nil
        else
            local options = form(template.options)
            if not options then return false,L.invalid end
            event = insertEvent(state,options,now)
            if not event then return false,L.invalid end
        end
    elseif action == 'preferences' then
        if type(data.mute) ~= 'boolean' then return false,L.invalid end
        profile(state,id).muteAnnouncements = data.mute
    elseif action == 'automatic' then
        state.automatic = not state.automatic
    elseif action == 'claim' then
        local result, errorMessage = claim(state,id,player,short(data.key,70))
        if not result then return false,errorMessage end
        state = result
    elseif action == 'review' then
        local entry = state.ledger[short(data.key,70) or '']
        if not entry or entry.status ~= 'applying' then return false,L.invalid end
        if entry.kind == 'fee' then
            if data.outcome == 'charged' then
                local linked = state.events[entry.event]
                if not linked then return false,L.invalid end
                ledger(state, 'review:' .. entry.event .. ':' .. entry.id, entry.id, linked,
                    {label='استرداد رسوم بعد المراجعة',kind='cash',amount=entry.amount})
                entry.status = 'done'
            elseif data.outcome == 'clear' then
                state.ledger[data.key] = nil
            else return false,L.invalid end
        elseif data.outcome == 'done' then entry.status = 'done'
        elseif data.outcome == 'clear' then entry.status = 'pending'
        else return false,L.invalid end
    elseif action == 'buy' then
        local key = short(data.key,40)
        local item = key and Server.Store.Enabled and Server.Store.Items[key]
        local p = profile(state,id)
        local day = E.periods(state,now)
        local stock = key and (state.purchases[key] or {count=0})
        if not item or p.points < item.price or p.titles[key] or stock.count >= item.stock then return false,L.invalid end
        p.bought = p.bought or {}
        local purchase = p.bought[key]
        if purchase and purchase.day == day and purchase.count >= item.limit then return false,L.invalid end
        p.bought[key] = {day=day,count=(purchase and purchase.day == day and purchase.count or 0)+1,at=now,price=item.price}
        p.points, p.titles[key] = p.points-item.price, item.label
        stock.count = stock.count + 1
        state.purchases[key] = stock
    elseif action == 'ban' then
        local hours = integer(data.hours,0,720)
        if target == 'nil' or not hours then return false,L.invalid end
        profile(state,target).ban = hours > 0 and now + hours*3600 or nil
        if hours > 0 then
            for _, other in pairs(state.events) do
                local participant = other.members[target]
                if isActive(other) and participant and (participant.status == 'joined' or participant.status == 'wait') then
                    participant.status = 'kicked'
                    refund(state,other,target)
                    if other.state == 'registration' then promote(other) end
                end
            end
        end
    elseif not event or (not permissions[action] and not E.canSee(event,id,false)) then
        return false,L.invalid
    elseif action == 'edit' and event.state == 'draft' then
        local options = form(data)
        if not options then return false,L.invalid end
        for key,value in pairs(options) do event[key] = value end
    elseif action == 'delete' and (event.state == 'draft' or event.state == 'scheduled') then
        state.events[event.id] = nil
    elseif action == 'schedule' and (event.state == 'draft' or event.state == 'scheduled') then
        local minutes = integer(data.minutes,1,43200)
        if not minutes then return false,L.invalid end
        event.scheduled, event.state = now + minutes*60, 'scheduled'
    elseif action == 'publish' and (event.state == 'draft' or event.state == 'scheduled') then
        if activeCount(state) >= Server.Limits.Concurrent then return false,L.invalid end
        openRegistration(event,now)
        if not event.private and event.permission == '' then broadcast = 'فتح التسجيل: ' .. event.name end
    elseif action == 'start' and event.state == 'registration' and now < event.deadline then
        if #eligible(event) < event.minimum then return false,L.invalid end
        event.state, event.deadline = 'countdown', now + event.countdown
    elseif action == 'stop' and event.state == 'running' then
        finish(state,event,now,false)
    elseif action == 'cancel' and (isActive(event) or event.state == 'scheduled') then
        finish(state,event,now,true)
    elseif action == 'lock' and event.state == 'registration' and not event.locked and now < event.deadline then
        event.locked = true
    elseif action == 'unlock' and event.state == 'registration' and event.locked and now < event.deadline then
        event.locked = nil
        for _ = 1, event.maximum do
            if not promote(event) then break end
        end
    elseif action == 'extend' and event.state == 'registration' then
        local minutes = integer(data.minutes,1,120)
        if not minutes then return false,L.invalid end
        event.deadline = math.min(math.max(now,event.deadline)+minutes*60,now+Server.Limits.Registration)
    elseif action == 'announce' and isActive(event) and not event.private and event.permission == '' then
        broadcast = 'فعالية: ' .. event.name
    elseif action == 'join' and event.state == 'registration' and not event.locked and now < event.deadline then
        if (state.players[id] and (state.players[id].ban or 0) > now) or (member and member.status == 'kicked') then return false,L.blocked end
        if member and (member.status == 'joined' or member.status == 'wait' or member.paid) then return false,L.invalid end
        for _, other in pairs(state.events) do
            local participation = other.members[id]
            if isActive(other) and participation and (participation.status == 'joined' or participation.status == 'wait') then return false,L.invalid end
        end
        if not member then
            local accounts = 0
            for _ in pairs(event.members) do accounts = accounts + 1 end
            if accounts >= Server.Limits.EventAccounts then return false,L.invalid end
        end
        local full = countMembers(event,'joined') >= event.maximum
        if full and (event.fee > 0 or countMembers(event,'wait') >= Server.Limits.Waiting) then return false,L.invalid end
        event.sequence = event.sequence + 1
        member = {status=full and 'wait' or 'joined', order=event.sequence, name=short(E.vrp.getPlayerName({player}),100) or id}
        if event.fee > 0 then
            local paid, errorMessage = charge(state,event,id,player,member)
            if not paid then return false,errorMessage end
        end
        if not full then member.team = teamFor(event) end
        event.members[id] = member
        message = full and L.waiting or L.joined
    elseif action == 'promote' and event.state == 'registration' and not event.locked and now < event.deadline
        and member and member.status == 'wait' and countMembers(event,'joined') < event.maximum then
        promote(event)
    elseif action == 'leave' and isActive(event) and member and (member.status == 'joined' or member.status == 'wait') then
        member.status = 'left'
        if event.state == 'registration' then refund(state,event,id) promote(event) end
    elseif (action == 'invite' or action == 'admit') and event.state == 'registration'
        and (action == 'admit' or (member and member.status == 'joined')) then
        local invited = E.source(target)
        if not invited or target == id or event.invites[target]
            or (event.permission ~= '' and not E.vrp.hasPermission({tonumber(target),event.permission})) then return false,L.invalid end
        local invitations = 0
        for _ in pairs(event.invites) do invitations = invitations + 1 end
        if invitations >= Server.Limits.EventAccounts then return false,L.invalid end
        event.invites[target] = true
        recipient, notifyMessage = target, 'دعوة للمشاركة في ' .. event.name
    elseif (action == 'team' or action == 'move') and event.state == 'registration' then
        local selected = action == 'team' and member or event.members[target]
        local team = integer(data.team,1,event.teams)
        if not selected or selected.status ~= 'joined' or not team then return false,L.invalid end
        local count, cap = 0, math.ceil(event.maximum / event.teams)
        for _, candidate in pairs(event.members) do
            if candidate ~= selected and candidate.status == 'joined' and candidate.team == team then count = count + 1 end
        end
        if count >= cap then return false,L.invalid end
        selected.team = team
    elseif action == 'kick' and isActive(event) and event.members[target]
        and (event.members[target].status == 'joined' or event.members[target].status == 'wait') then
        event.members[target].status = 'kicked'
        refund(state,event,target)
        recipient, notifyMessage = target, 'تم استبعادك من ' .. event.name
        if event.state == 'registration' then promote(event) end
    elseif action == 'refund' and event.state ~= 'draft' and event.state ~= 'scheduled' then
        if not refund(state,event,target) then return false,L.invalid end
    elseif action == 'winner' and event.state == 'running' and event.mode == 'manual'
        and event.members[target] and event.members[target].status == 'joined' and E.source(target) then
        event.selected = target
    elseif action == 'answer' and event.state == 'running' and now < event.deadline and member and member.status == 'joined' then
        local game = E.games[event.mode]
        if not game.answer or not game.answer(event,member,data,now) then return false,L.invalid end
    else
        return false,L.invalid
    end
    if broadcast then recordNews(state,broadcast,now) end
    local log
    if action ~= 'answer' and action ~= 'preferences' then log = audit(state,id,action,event,target ~= 'nil' and target or nil) end
    return state,message or L.ok,broadcast,recipient,notifyMessage,log
end

local dispatcherBusy = false
local rate = {}
AddEventHandler('playerDropped', function() rate[source] = nil end)

function E.perform(player, action, data)
    if not E.ready then return false,L.offline end
    if type(action) ~= 'string' or #action > 24 or type(data) ~= 'table' then return false,L.invalid end
    local id = E.uid(player)
    if not id then return false,L.denied end
    if dispatcherBusy then return false,L.busy end
    local time = GetGameTimer()
    local entry = rate[player] or {all=-100000,actions={}}
    local previous = entry.actions[action]
    if time - entry.all < Server.Limits.Cooldown or (previous and time - previous < Server.Limits.ActionCooldown) then return false,L.busy end
    entry.all = time
    if permissions[action] or L.actions[action] then entry.actions[action] = time end
    rate[player] = entry
    if permissions[action] and (not E.has(id,'OpenAdmin') or not E.has(id,permissions[action])) then
        E.logHook('Security','رفض إجراء إداري للحساب ' .. id)
        return false,L.denied
    end
    dispatcherBusy = true
    local ok, success, message = xpcall(function()
        local state, result, broadcast, recipient, notifyMessage, log = apply(E.copy(E.state),action,data,player,id,os.time())
        if not state then return false,result end
        if not E.persist(state) then return false,L.offline end
        if broadcast then announce(broadcast) end
        local target = recipient and E.source(recipient)
        if target then E.notify(target,notifyMessage) end
        if log then
            local category = (action == 'claim' or action == 'refund' or action == 'buy' or action == 'review') and 'Economy'
                or ((action == 'join' or action == 'leave' or action == 'kick' or action == 'move' or action == 'team' or action == 'invite' or action == 'ban') and 'Participants' or 'Lifecycle')
            E.logHook(category, ('%s | %s (%s) | %s | %s | %s'):format(log.action,log.actorName or 'لاعب',id,
                log.event or '—',log.name or '—',log.target or '—'))
        end
        return true,result
    end,debug.traceback)
    dispatcherBusy = false
    if not ok then E.diagnostic('خطأ في تنفيذ إجراء.',success) return false,L.offline end
    return success,message
end

local nextScheduleCheck = 0
local function tick()
    local now = os.time()
    local checkSchedule = E.state.automatic and now >= nextScheduleCheck
    if checkSchedule then nextScheduleCheck = now + 10 end
    local needed = checkSchedule
    for _, event in pairs(E.state.events) do
        if (event.deadline and event.deadline <= now) or (event.state == 'scheduled' and event.scheduled <= now) then
            needed = true
            break
        end
    end
    if not needed then return end
    local state, changed, news, results = E.copy(E.state), false, {}, {}
    for _, event in pairs(state.events) do
        if event.deadline and event.deadline <= now then
            if event.state == 'registration' then
                if event.autostart and #eligible(event) >= event.minimum then
                    event.state,event.deadline = 'countdown', now+event.countdown
                else
                    finish(state,event,now,true)
                    audit(state,nil,'cancel',event)
                end
                changed = true
            elseif event.state == 'countdown' then
                if #eligible(event) >= event.minimum then
                    event.state,event.started,event.deadline = 'running',now,now+event.duration
                else finish(state,event,now,true) audit(state,nil,'cancel',event) end
                changed = true
            elseif event.state == 'running' then
                finish(state,event,now,false)
                audit(state,nil,'stop',event)
                results[#results+1] = event
                changed = true
            end
        elseif event.state == 'scheduled' and event.scheduled <= now and activeCount(state) < Server.Limits.Concurrent then
            openRegistration(event,now)
            if not event.private and event.permission == '' then news[#news+1] = 'فتح التسجيل: ' .. event.name end
            audit(state,nil,'publish',event)
            changed = true
        end
    end
    if checkSchedule then
        local clock = os.date('!*t',now+Server.Automatic.OffsetMinutes*60)
        local day = E.periods(state,now)
        for _, schedule in ipairs(Server.Automatic.Entries) do
            if clock.hour == schedule.hour and clock.min == schedule.minute and
                (schedule.weekday == 0 or schedule.weekday == clock.wday) and state.schedules[schedule.key] ~= day
                and #GetPlayers() >= schedule.online and activeCount(state) < Server.Limits.Concurrent then
                local event = insertEvent(state,form({name=schedule.name,mode=schedule.mode,autostart=true}),now)
                if event then
                    openRegistration(event,now)
                    state.schedules[schedule.key] = day
                    audit(state,nil,'publish',event)
                    news[#news+1] = 'فتح التسجيل: ' .. event.name
                    changed = true
                end
            end
        end
    end
    for _, message in ipairs(news) do recordNews(state,message,now) end
    if changed and E.persist(state) then
        for _, message in ipairs(news) do announce(message) end
        for _, event in ipairs(results) do
            local winner = event.winner and E.source(event.winner)
            if winner then E.notify(winner,'فزت في ' .. event.name,'success') end
        end
    end
end

CreateThread(function()
    while true do
        Wait(Server.Limits.Tick)
        if E.ready and not dispatcherBusy then
            dispatcherBusy = true
            local ok, err = xpcall(tick,debug.traceback)
            dispatcherBusy = false
            if not ok then E.diagnostic('تعذر تحديث الفعاليات المجدولة.',err) end
        end
        if E.pushHud then E.pushHud() end
    end
end)
