local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
E = { vrp = Proxy.getInterface("vRP"), client = Tunnel.getInterface("vRP", GetCurrentResourceName()) }
local queue, sending = {}, false

function E.logHook(category, message)
    local url = Server.Webhooks[category]
    if not url or url == '' then url = Server.Webhooks.Default end
    if url == '' or #queue >= Server.WebhookQueue then return end
    queue[#queue + 1] = { url = url, attempts = 0, body = json.encode({
        username = Config.Name, allowed_mentions = {parse = {}},
        embeds = {{title='سجل الفعاليات', description=message, color=8388640, timestamp=os.date('!%Y-%m-%dT%H:%M:%SZ')}}
    }) }
    if sending then return end
    sending = true
    local function send()
        local entry = queue[1]
        if not entry then sending = false return end
        entry.attempts = entry.attempts + 1
        PerformHttpRequest(entry.url, function(status, _, headers)
            status = tonumber(status) or 0
            local delay = Server.WebhookInterval
            if status == 429 and entry.attempts < 3 then
                local retry = tonumber(headers and (headers['retry-after'] or headers['Retry-After'])) or 2
                delay = math.max(delay, math.min(60000, retry * 1000))
            else
                if status < 200 or status >= 300 then print('[slom_events] تعذر إرسال سجل ديسكورد (' .. status .. ')') end
                table.remove(queue, 1)
            end
            SetTimeout(delay, send)
        end, 'POST', entry.body, {['Content-Type']='application/json'})
    end
    send()
end

function E.diagnostic(message, details)
    print('[slom_events] ' .. message)
    if Server.Debug and details then print(details) end
    E.logHook('System', message)
end

local function awaitSQL(run)
    local response = promise.new()
    local settled = false
    SetTimeout(10000, function()
        if settled then return end
        settled = true
        response:resolve(false)
    end)
    run(function(value)
        if settled then return end
        settled = true
        response:resolve(value or false)
    end)
    return Citizen.Await(response)
end

function E.persist(nextState)
    local affected = awaitSQL(function(callback)
        MySQL.Async.execute(
            'UPDATE slom_events_state SET payload=@payload, revision=revision+1 WHERE id=1 AND revision=@revision',
            {['@payload']=json.encode(nextState), ['@revision']=E.revision}, callback)
    end)
    if affected ~= 1 then
        E.ready = false
        E.diagnostic('توقف الحفظ. تحقق من اتصال قاعدة البيانات وأعد تشغيل المورد بعد المراجعة.')
        return false
    end
    E.state = nextState
    E.revision = E.revision + 1
    return true
end

function E.copy(value)
    if type(value) ~= 'table' then return value end
    local result = {}
    for key, child in pairs(value) do result[key] = E.copy(child) end
    return result
end

function E.uid(player)
    local id = player and E.vrp.getUserId({player})
    if type(id) == 'number' and id > 0 then return tostring(id) end
end

function E.source(id)
    local player = E.vrp.getUserSource({tonumber(id)})
    if player and E.uid(player) == id then return player end
end

function E.has(id, key)
    return id and E.vrp.hasPermission({tonumber(id), Server.Permissions[key]}) == true
end

function E.notify(player, message, kind)
    if Server.Notify.Adapter == 'pNotify' then
        TriggerClientEvent('pNotify:SendNotification', player, {type=kind or 'info', text=message:gsub('&','&amp;'):gsub('<','&lt;'):gsub('>','&gt;'), timeout=Server.Notify.Duration})
    else
        TriggerClientEvent('slom_events:notice', player, message)
    end
end

local function validConfig()
    local seen = {}
    for key, value in pairs(Server.Permissions) do
        if type(value) ~= 'string' or value == '' or seen[value] then return false end
        seen[value] = key
    end
    local defaults, limits = Server.Defaults, Server.Limits
    if defaults.minimum < 1 or defaults.maximum < defaults.minimum or defaults.maximum > limits.Participants
        or defaults.registration < 30 or defaults.registration > limits.Registration
        or defaults.duration < 10 or defaults.duration > limits.Duration or defaults.countdown < 1
        or defaults.countdown > 120 or Server.Progress.PerLevel < 1 or Server.Progress.SeasonDays < 1
        or Server.Progress.Daily < 1 or limits.Tick < 250 or #Server.Quiz == 0 then return false end
    for _, question in ipairs(Server.Quiz) do
        if type(question.text) ~= 'string' or type(question.options) ~= 'table'
            or #question.options < 2 or not question.options[question.correct] then return false end
    end
    for key, item in pairs(Server.Store.Items) do
        if type(key) ~= 'string' or type(item.label) ~= 'string' or not math.tointeger(item.price)
            or item.price < 1 or not math.tointeger(item.stock) or item.stock < 1
            or not math.tointeger(item.limit) or item.limit < 1 then return false end
    end
    local schedules = {}
    for _, entry in ipairs(Server.Automatic.Entries) do
        if type(entry.key) ~= 'string' or schedules[entry.key] or not Server.Games[entry.mode]
            or entry.mode == 'manual' or not math.tointeger(entry.hour) or entry.hour < 0 or entry.hour > 23
            or not math.tointeger(entry.minute) or entry.minute < 0 or entry.minute > 59
            or not math.tointeger(entry.weekday) or entry.weekday < 0 or entry.weekday > 7
            or not math.tointeger(entry.online) or entry.online < 0 or type(entry.name) ~= 'string' then return false end
        schedules[entry.key] = true
    end
    return true
end

local function stateTableExists()
    local rows = awaitSQL(function(callback)
        MySQL.Async.fetchAll([[
            SELECT TABLE_NAME FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'slom_events_state'
        ]], {}, callback)
    end)
    if type(rows) ~= 'table' then return nil end
    return rows[1] ~= nil
end

local function readState()
    return awaitSQL(function(callback)
        MySQL.Async.fetchAll('SELECT revision,payload FROM slom_events_state WHERE id=1', {}, callback)
    end)
end

local function loadState()
    local exists = stateTableExists()
    if exists == nil then
        return nil, 'تعذر فحص جدول الفعاليات. تحقق من اتصال mysql-async وقاعدة البيانات المحددة.'
    end
    if not exists then
        awaitSQL(function(callback)
            MySQL.Async.execute([[
                CREATE TABLE IF NOT EXISTS slom_events_state (
                    id TINYINT UNSIGNED NOT NULL,
                    revision BIGINT UNSIGNED NOT NULL DEFAULT 0,
                    payload LONGTEXT NOT NULL,
                    PRIMARY KEY (id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ]], {}, callback)
        end)
        if not stateTableExists() then
            return nil, 'تعذر إنشاء جدول الفعاليات. امنح حساب mysql-async صلاحية CREATE على قاعدة الخادم، أو نفذ sql/install.sql بحساب يملكها.'
        end
    end

    local rows = readState()
    if type(rows) ~= 'table' then
        return nil, 'تعذرت قراءة جدول الفعاليات. تحقق من صلاحية SELECT ومن بنية الجدول.'
    end
    if not rows[1] then
        local initial = {
            version=1, nextEvent=0, events={}, players={}, ledger={}, logs={},
            schedules={}, purchases={}, automatic=false, created=0
        }
        awaitSQL(function(callback)
            MySQL.Async.execute(
                'INSERT IGNORE INTO slom_events_state (id, revision, payload) VALUES (1, 0, @payload)',
                {['@payload']=json.encode(initial)}, callback)
        end)
        rows = readState()
        if type(rows) ~= 'table' or not rows[1] then
            return nil, 'تعذر إضافة سجل الفعاليات الأولي. تحقق من صلاحية INSERT لحساب mysql-async.'
        end
    end
    return rows[1]
end

MySQL.ready(function()
    CreateThread(function()
        local valid, result = pcall(validConfig)
        if not valid or not result then E.diagnostic('إعدادات النظام غير صالحة.') return end
        local row, reason = loadState()
        if not row then E.diagnostic(reason) return end
        local ok, state = pcall(json.decode, row.payload)
        if not ok or type(state) ~= 'table' or state.version ~= 1 or not tonumber(row.revision) then
            E.diagnostic('سجل الفعاليات الحالي غير صالح. راجع نسخته الاحتياطية وبنية الجدول.')
            return
        end
        state.templates = state.templates or {}
        state.news = state.news or {}
        E.revision = tonumber(row.revision)
        if state.created == 0 then
            state.created, state.automatic = os.time(), Server.Automatic.Enabled
            if not E.persist(state) then return end
        else
            E.state = state
        end
        E.ready = true
        E.diagnostic('نظام الفعاليات جاهز.')
    end)
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        print('[slom_events] تم إيقاف الخدمة.')
    end
end)
