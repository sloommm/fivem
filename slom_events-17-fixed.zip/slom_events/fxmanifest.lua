fx_version 'adamant'
game 'gta5'
author 'MADE BY SLOM'
description 'نظام الفعاليات'
ui_page 'html/index.html'
files { 'html/index.html', 'html/ui.css', 'html/ui.js', 'html/assets/*' }
dependencies { 'vrp_mysql', 'mysql-async', 'vrp' }
server_scripts {
    '@vrp/lib/utils.lua',
    '@mysql-async/lib/MySQL.lua',
    'config/config.lua',
    'config/language_ar.lua',
    'config/server.lua',
    'server/storage.lua',
    'server/games.lua',
    'server/events.lua',
    'server/transport.lua',
    'server/phone.lua'
}
client_script 'client/main.lua'
