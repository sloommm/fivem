Server = {
    Limits = {
        Templates = 40, -- الحد الأعلى للقوالب المحفوظة
        EventCount = 400, -- سقف السجلات ويشمل الفعاليات المنتهية
        Concurrent = 5, -- أقصى عدد فعاليات مفتوحة أو جارية معاً
        Participants = 80, -- سقف التسجيل الفعلي لكل فعالية
        EventAccounts = 300, -- سقف الحسابات المسجلة أو المدعوة لكل فعالية
        Waiting = 40, -- أقصى عدد في قائمة الانتظار
        Fee = 10000, -- الحد الأعلى لرسوم التسجيل النقدية
        Duration = 3600, -- الحد الأعلى لمدة اللعب بالثواني
        Registration = 7200, -- الحد الأعلى لمدة التسجيل بالثواني
        Cooldown = 250, -- مهلة بين طلبات اللاعب بالمللي ثانية
        ActionCooldown = 700, -- مهلة إعادة الإجراء نفسه بالمللي ثانية
        Tick = 1000, -- فاصل معالجة المواعيد بالمللي ثانية
        Logs = 180 -- عدد السجلات الإدارية المحتفظ بها
    },
    Defaults = {
        registration = 300, -- مدة التسجيل الافتراضية بالثواني
        duration = 120, -- مدة اللعب الافتراضية بالثواني
        countdown = 15, -- مدة العد التنازلي الافتراضية
        minimum = 2, -- الحد الأدنى الافتراضي للمشاركين
        maximum = 20 -- الحد الأعلى الافتراضي للمشاركين
    },
    Games = {
        manual = true, -- إدارة النتيجة يدوياً
        draw = true, -- قرعة بين المشاركين المتصلين
        quiz = true -- احتساب الإجابات على الخادم
    },
    Quiz = {
        { text = 'كم ضلعاً للمثلث؟', options = {'٢','٣','٤'}, correct = 2 }, -- السؤال وخياراته ورقم الإجابة
        { text = 'ما عاصمة السعودية؟', options = {'جدة','الدمام','الرياض'}, correct = 3 }, -- السؤال وخياراته ورقم الإجابة
        { text = 'كم دقيقة في الساعة؟', options = {'٦٠','١٠٠','٢٤'}, correct = 1 } -- السؤال وخياراته ورقم الإجابة
    },
    Permissions = {
        OpenAdmin = 'events.admin', -- عرض واجهة الإدارة
        Create = 'events.create', -- إنشاء المسودات ونسخها
        Edit = 'events.edit', -- التعديل وفتح التسجيل وتمديده
        Delete = 'events.delete', -- حذف المسودات
        Start = 'events.start', -- بدء العد التنازلي
        Stop = 'events.stop', -- إنهاء الفعالية
        Cancel = 'events.cancel', -- إلغاء الفعالية
        ManagePlayers = 'events.players', -- عرض قائمة المشاركين
        ManageTeams = 'events.teams', -- تعديل فرق المشاركين
        Kick = 'events.kick', -- استبعاد مشارك
        Ban = 'events.ban', -- تقييد مشاركة حساب
        Rewards = 'events.rewards', -- تسوية عمليات التسليم المعلقة
        Refund = 'events.refund', -- إصدار مستحق استرداد
        SetWinner = 'events.winner', -- تعيين فائز لفعالية يدوية
        Announce = 'events.announce', -- إرسال إعلان عام
        Schedule = 'events.schedule', -- جدولة فعالية
        Automatic = 'events.automatic', -- تبديل الجدولة المتكررة
        Logs = 'events.logs', -- مراجعة السجل الإداري
        Diagnostics = 'events.diagnostics' -- عرض مراقبة الخدمة
    },
    Economy = {
        Enabled = false, -- تمكين رسوم التسجيل والجوائز المرتبطة باقتصاد الإطار
        Max = 50000, -- الحد الأعلى لقيمة الجائزة من نوع نقد أو بنك أو عنصر
        Rewards = {
            none = { label = 'بدون جائزة إضافية', kind = 'none', amount = 0 }, -- خيار بلا جائزة
            cash = { label = 'جائزة نقدية', kind = 'cash', amount = 1000 }, -- جائزة للمحفظة
            bank = { label = 'جائزة بنكية', kind = 'bank', amount = 1500 } -- جائزة للحساب البنكي
            -- مثال عنصر: item = { label = 'ماء', kind = 'item', amount = 2, item = 'water' }
        }
    },
    Progress = {
        XP = 25, -- خبرة لكل مشاركة مؤهلة
        WinXP = 50, -- خبرة إضافية للفائز
        Points = 20, -- نقاط الفائز
        PerLevel = 100, -- الخبرة اللازمة للمستوى
        Daily = 5, -- عدد المشاركات التي تمنح خبرة خلال يوم خادم واحد
        SeasonDays = 30, -- طول الموسم بالأيام
        DailyGoal = 2, -- هدف المشاركات اليومي
        WeeklyGoal = 5 -- هدف المشاركات الأسبوعي
    },
    Store = {
        Enabled = true, -- تمكين شراء الألقاب بالنقاط
        Items = {
            champion = { label = 'بطل الفعاليات', price = 40, stock = 100, limit = 1 } -- اللقب والسعر والمخزون وحد الشراء اليومي
        }
    },
    Automatic = {
        Enabled = false, -- تشغيل الجداول المتكررة عند التثبيت الأول
        OffsetMinutes = 180, -- فرق توقيت الجداول عن UTC بالدقائق
        Entries = {
            { key='evening', hour=20, minute=0, weekday=0, online=5, name='قرعة المساء', mode='draw' } -- توقيت محلي، ٠ يومياً أو ١ الأحد حتى ٧ السبت
        }
    },
    Notify = {
        Adapter = 'pNotify', -- pNotify أو nui
        Duration = 3800 -- مدة ظهور تنبيه pNotify بالمللي ثانية
    },
    Webhooks = {
        Default = '', -- عنوان ويب هوك احتياطي، فارغ لتعطيله
        Lifecycle = '', -- عنوان ويب هوك إدارة الفعالية
        Participants = '', -- عنوان ويب هوك المشاركة والفرق
        Economy = '', -- عنوان ويب هوك الجوائز والاسترداد والمتجر
        Security = '', -- عنوان ويب هوك رفض الصلاحيات
        System = '' -- عنوان ويب هوك تشغيل الخدمة وأخطائها
    },
    WebhookQueue = 60, -- الحد الأعلى لطابور الويب هوك
    WebhookInterval = 2000, -- فاصل محاولة الإرسال بالمللي ثانية
    Debug = false -- تسجيل تفاصيل الأخطاء البرمجية في وحدة التحكم
}
